class Hello:
    def __init__(self):
        print("Hello Initialized")
    def hello(self):
        print("Hello")